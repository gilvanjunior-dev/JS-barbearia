# JS Barbearia 💈
Site institucional e agendamento online de alto padrão para a **JS Barbearia** em Teresina - PI.

## 🎨 Identidade Visual
- **Cor Primária:** Dourado Premium (`#D4AF37`)
- **Cor Secundária:** Midnight Navy (`#1A1A2E`)
- **Tipografia:** Playfair Display + Raleway

## 📍 Localização
- Av. Joaquim Ribeiro, 1925 - Centro (Sul), Teresina - PI, 64001-480
- Telefone / WhatsApp: (86) 99996-4233

## 🚀 Como Executar
Basta abrir o arquivo `index.html` em qualquer navegador moderno.
